export {
  isInsertActionId,
  runInsertMenuAction,
  type InsertActionId,
  type MenuToastPayload,
} from "./insert-menu-controller";
